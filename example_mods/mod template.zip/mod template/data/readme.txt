song data files go here (charts, scripts, and dialouge for week 6)
scripts in the song folders will only work in that song